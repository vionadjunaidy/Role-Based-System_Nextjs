import { NextResponse } from 'next/server';

export function middleware(request) {
  // For now, this is a simple middleware that allows all routes
  // In a real application, you would check for authentication tokens here
  // and redirect unauthenticated users to the login page
  
  const { pathname } = request.nextUrl;
  
  // Allow access to the login and signup pages and static assets
  if (pathname === '/' || pathname === '/signup' || pathname.startsWith('/_next') || pathname.startsWith('/api')) {
    return NextResponse.next();
  }
  
  // For protected routes (/dashboard, /profile), you would typically:
  // 1. Check for authentication token in cookies/headers
  // 2. Verify the token is valid
  // 3. Check user role and permissions
  // 4. Redirect to login if not authenticated
  
  // For now, we'll allow all routes since this is frontend-only
  return NextResponse.next();
}

export const config = {
  matcher: [
    /*
     * Match all request paths except for the ones starting with:
     * - api (API routes)
     * - _next/static (static files)
     * - _next/image (image optimization files)
     * - favicon.ico (favicon file)
     */
    '/((?!api|_next/static|_next/image|favicon.ico).*)',
  ],
};
